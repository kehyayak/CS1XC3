/**
 * @file course.c
 * @author Khach Kehyayan (kehyayak)
 * @brief The functions in this file are responsible for several tasks such as enrolling students into a course,
 *        finding and printing course name, course code, and total students along with their names, identifying and
 *        printing the students who have passed the course along with acknowledging the top student.
 * 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Enrolls a new student (of Student type) to course (of Course type), by reallocating space in
 *        course for the additional student
 * 
 * @param course 
 * @param student 
 * @return nothing - it is a void function.
 */
 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // If there is only one student entered, it allocates space to add one more student in the course.
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); 
  }
  // Otherwise, when there is more than one student in the course, it will reallocate to make space for one more student.
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // Enrolls the student in the course
  course->students[course->total_students - 1] = *student; 
}

/**
 * @brief print important information about the course suchas the course name, course code, 
 *        total number of students, along with the names of the students.
 * 
 * @param course 
 * @return nothing - it is a void function.
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // iterates through students and prints each of their names
  for (int i = 0; i < course->total_students; i++)  
    print_student(&course->students[i]);
}

/**
 * @brief The top_student function of type Student* finds the student with the highest 
 *        average in the particular course. This is done by using a for loop that uses
 *        a comparison algorithm to find the highest possible grade by comparing each
 *        student's grade by the previous one and updating a value to record the current
 *        max value accordingly.
 * 
 * @param course 
 * @return Student*
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; // if there are no students in a course, returns null since there cannot be a top student
 
  // initalizes student average and max average to temporary values, to be updated later
  double student_average = 0;
  double max_average = average(&course->students[0]); 
  Student *student = &course->students[0];

  /* iterates through every student average in the course and compares it to the initalized
     maximum average, and updates the maximum average if the student average is found to be
     greater. The final value of max_average will be the average of the top student. 
  */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student; // returns the top student
}

/**
 * @brief The function *passing is of type Student and it is mainly responsible for
 *        iterating through the grades of the students and determining the number of students
 *        who have passed, or, in other words, have at least a 50% average. 
 * 
 * @param course  
 * @param total_passing 
 * @return Student* 
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  /* 
     Determines the number of successful students by iterating through the grades of all students
     and increments the count variable which will represent the number of successful students
  */
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;

  // uses the number of successful student to accordingly allocate space to "passing" 
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // iterates through the students course and finds the successful students
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50) // if the student has above a 50, append the student info to the list of passing students
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  /* 
     assigns the parameter of the function total_passing the count obtained in the loop
     which is equivalent to the number of students who have passed the course
  */
  *total_passing = count;

  return passing; //returns the number of students that have passed the course
}