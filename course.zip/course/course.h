/**
 * @file course.h
 * @author Khach Kehyayan (kehyayak)
 * @brief This file contains the typedef struct for the Course type, as well as the 
 *        defintions of the functions that are used in course.c
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Below is the typedef struct of the Course type. It is responsible for storing
 *        information about the particular course such as course title, course code, the students
 *        enrolled in the course, as well as the total number of students registered in it.
 *        The below information is crucial for course.c to function and to store important data
 *        that makes this program functional.
 * 
 */
 
typedef struct _course 
{
  char name[100]; /**< the course name */
  char code[10]; /**< the course code */
  Student *students; /**< the students in the course*/
  int total_students; /**< the total number of students enrolled in the course*/
} Course;


/**
 * @brief Function declaration for enroll_student that is used in course.c
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief Function declaration for print_course that is used in course.c
 * 
 * @param course 
 */
void print_course(Course *course);

/**
 * @brief Function declaration for *top_student that is used in course.c
 * 
 * @param course 
 * @return Student* 
 */
Student *top_student(Course* course);

/**
 * @brief Function declaration for *passing that is used in course.c
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing);


