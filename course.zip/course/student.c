/**
 * @file student.c
 * @author Khach Kehyayan (kehyayak)
 * 
 * @brief The functions in this file are responsible for several tasks such as assigning a grade to a student,
 *        finding the average of a student, print the name, student ID, grades, and overall average of a student
 *        and Randomize student information 
 * 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief This function is mainly responsible for adding the grades of a student, which has type Student,
 *        to a list of student grades. This will be important to determine averages.
 *
 * @param student 
 * @param grade 
 * @return nothing - it is a void function.
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  //if the student has only one grade, additional memory is allocated for another grade to be inputted. 
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  // if the student has more than one grade, additional memory/space is reallocated using realloc
  else 
  { 
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // assigns a grade to a student
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculates the average of a student.
 * 
 * @param student 
 * @return double - the function returns the average of a student (type Double)
 */

double average(Student* student)
{
  
  if (student->num_grades == 0) return 0; // if the student has 0 grades, their average is initialized to 0

  /* 
     if the student does not have 0 grades, all of the student's grades are added together and divided 
     by the number of grades to determine average
  */
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades); // returns average of student, type Double
}

/**
 * @brief Prints important information about the student, such as:
 *        - Name
 *        - Student ID
 *        - Grades
 *        - Average rounded to two decimal place.
 * 
 * @param student 
 * @return nothing - it is a void function.
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief This function is mainly responsible for returning a student with randomized
 *        information such as first name, last name, student ID, grades, and num_grades 
 * 
 * @param grades
 * @return Student*
 */

Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student)); // Creates space/memory for a new student

  // assigns the student a random first name from the first_names in the series of first names above
  strcpy(new_student->first_name, first_names[rand() % 24]);
   // assigns the student a random first name from the last_names in the series of last names above
  strcpy(new_student->last_name, last_names[rand() % 24]); 

  // generates student ID that is 11 digits long
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  /* 
    assigns randm grades to the new student by using rand() and add_grade which handles
    the student addition process
  */

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  // returns the new student
  return new_student;
}