/**
 * @mainpage Creating courses function demonstration
 *  
 * The creating courses function demonstration shows how a pointer with type Course 
 *  is created, which carries information such as:
 * - printing the course title
 * - printing the names of the top students
 * - total number of students passing
 * 
 * @file main.c
 * @author Khach Kehyayan (kehyayak)
 * @brief Runs demonstration code for the course creating methods which assigns
 *        students registered to a course and determines important information
 *        such as number of students passed and top students in the course.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */ 

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief the function below creates a course and registers students into it by generating 20
 *        random students into the course with 8 different grades. Furthermore, it outputs 
 *        important data such as course name, names and number of students who have passed
 *        and the top students in the course.
 * 
 * @return int Since the main objective of the function is to print data, it will not be
 *             returning anything and will basically be acting as a void function. Therefore,
 *             it is said that the function will 'return 0;'
 * 
 */

int main()
{
  // generates a random unsigned integer by using current time
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course)); // Initializes a dynamically allocated space as 0 to a course MATH101
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // registers 20 random students with 8 grades and enrolls them into the MATH101 course.
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  // prints all the students registered in the course
  print_course(MATH101);

  // finds the top student using the course.c library and prints their name
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // goes through the grades and prints the total number of passing students along with their names
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}