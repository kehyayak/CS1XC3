 /**
 * @file student.h
 * @author Khach Kehyayan (kehyayak)
 * @brief This file contains the typedef struct for the Student type, as well as the definitions
 *        of the functons that are used in course.c
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
 
 /**
 * @brief Below is the typedef struct of the Student type. It is responsible for storing
 *        information about a particular student(s) such as student first name, last name,
 *        student id of length 11, grades, and the number of grades that is assigned to them
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< student's first name */
  char last_name[50];  /**< student's last name */
  char id[11];  /**< student's ID that is 11 digits long */
  double *grades;  /**< student's grades */
  int num_grades;  /**< number of grades assigned to a student */
} Student;

/**
 * @brief Function declaration for add_grade which is used in student.c
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student *student, double grade);

/**
 * @brief Function declaration for average  which is used in student.c
 * 
 * @param student 
 * @return double 
 */
double average(Student *student);

/**
 * @brief Function declaration for print_student  which is used in student.c
 * 
 * @param student 
 */
void print_student(Student *student);

/**
 * @brief Function declaration for generate_random_student  which is used in student.c
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades); 
